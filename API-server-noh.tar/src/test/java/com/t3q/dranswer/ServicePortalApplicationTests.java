package com.t3q.dranswer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}

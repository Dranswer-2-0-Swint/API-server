package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerDomainCreateDeleteRes {

	private String message;				// 응답메시지
	
}

package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerPodReadResSub {

	private String podName;					// 파드명
	
}

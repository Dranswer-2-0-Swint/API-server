package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerDeleteReq {

	private String projectName;					// 프로젝트명
	
}

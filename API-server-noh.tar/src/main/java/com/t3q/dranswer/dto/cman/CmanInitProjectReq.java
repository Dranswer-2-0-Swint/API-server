package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanInitProjectReq {

	private String projectName;			// 프로젝트명
	
}

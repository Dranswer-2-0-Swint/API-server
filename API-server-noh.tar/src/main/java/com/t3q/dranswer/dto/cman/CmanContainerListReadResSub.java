package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerListReadResSub {

	private String name;					// 컨테이너명
	private String alias;					// 컨테이너별칭
	private String description;				// 서렴ㅇ
	private String createTime;				// 컨테이너 생성 시각
	
}

package com.t3q.dranswer.dto.keycloak;

import java.util.List;

import lombok.Data;

@Data
public class KeycloakIntroSpectRoleRes {

	private List<String> roles;
}

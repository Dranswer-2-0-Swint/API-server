package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerDeployReqSub {

	private String domain;						// 컨테이너도메인
	private int port;							// 컨테이너도메인포트
	private String path = "/";					// 컨테이너도메인패스
	
}

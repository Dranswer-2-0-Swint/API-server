package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanImageReadResSub {

	private String name;				// 응답메시지

}

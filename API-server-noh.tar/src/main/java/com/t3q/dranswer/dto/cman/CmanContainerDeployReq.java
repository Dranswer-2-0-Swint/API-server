package com.t3q.dranswer.dto.cman;

import lombok.Data;

import java.util.List;

@Data
public class CmanContainerDeployReq {

	private boolean has_domain = false;						// 컨테이너도메인여부
	private List<CmanContainerDeployReqSub> domains;		// 컨테이너도메인목록
	
}

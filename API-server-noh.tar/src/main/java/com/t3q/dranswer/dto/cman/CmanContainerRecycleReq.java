package com.t3q.dranswer.dto.cman;

import lombok.Data;

@Data
public class CmanContainerRecycleReq {

	private String projectName;					// 프로젝트명
	
}
